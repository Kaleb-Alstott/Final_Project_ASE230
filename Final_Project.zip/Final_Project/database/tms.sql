-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 03:11 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `docs/bills`
--

CREATE TABLE `docs/bills` (
  `Doc_ID` mediumint(8) UNSIGNED NOT NULL,
  `Tenant_ID` mediumint(8) UNSIGNED NOT NULL,
  `Doc_Data` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Price` mediumint(9) NOT NULL,
  `Status` varchar(150) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Due_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `docs/bills`
--

INSERT INTO `docs/bills` (`Doc_ID`, `Tenant_ID`, `Doc_Data`, `Price`, `Status`, `Due_Date`) VALUES
(9, 47, 'Month #1', 5000, 'Not Paid', '2022-12-24');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `Home_ID` mediumint(8) UNSIGNED NOT NULL,
  `user_ID` mediumint(8) UNSIGNED NOT NULL,
  `Bio` text DEFAULT NULL,
  `Picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Sq_Feet` mediumint(9) NOT NULL,
  `Bedrooms` decimal(10,0) NOT NULL,
  `Baths` decimal(10,0) NOT NULL,
  `Year_Built` date NOT NULL,
  `School_District` varchar(75) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `is_available` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `street` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`Home_ID`, `user_ID`, `Bio`, `Picture`, `Sq_Feet`, `Bedrooms`, `Baths`, `Year_Built`, `School_District`, `is_available`, `street`, `city`, `state`, `zip`) VALUES
(31, 40, 'Very nice house for rent!', 'https://www.premierhomesca.com/wp-content/uploads/2020/03/EL3-Model-11-scaled-e1611704624780-1024x739.jpg', 5000, '5', '4', '0000-00-00', 'Campbell County', 0, '123 ABC', 'Waynesville', 'California', 41001),
(32, 40, 'Small house for rent. ', 'https://www.coolhouseplans.com/varnish-images/plans/56937/56937-b600.jpg', 1000, '3', '2', '0000-00-00', 'Campbell County ', 0, '8 Buttermilk Court', 'Alexandria', 'Kentucky', 41001),
(33, 40, 'Very nice house in east side Cincinnati!', 'https://www.thehousedesigners.com/images/plans/ROD/bulk/8773/cl-20-003-front-2-small_m.jpg', 4500, '4', '3', '0000-00-00', 'Boone', 0, '50 APPLE LANE', 'Cincinnati', 'Ohio', 410576),
(34, 40, 'Very cool upside down house for rent. ', 'https://ik.imagekit.io/archdez1/wp-content/uploads/2021/03/Pictures-Of-Ugly-Houses-4.jpg', 2000, '2', '2', '0000-00-00', 'Bracken', 0, '85 June Ave', 'Maysville', 'Kentucky', 41001),
(35, 40, 'Very large home. ', 'https://www.gannett-cdn.com/presto/2021/01/12/NPBD/08d0fd5e-2255-4d49-b608-e83342ae4615-PBN_POOL_REAR_535_N_County_Road_HiRes_PictureItSoldFL.jpg?width=1200&disable=upscale&format=pjpg&auto=webp', 10000, '9', '7', '0000-00-00', 'Boone', 1, '5 Pancake Court', 'Florence', 'Florida', 49121);

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `Tenant_ID` mediumint(8) UNSIGNED NOT NULL,
  `Home_ID` mediumint(8) UNSIGNED DEFAULT NULL,
  `First_Name` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Last_Name` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Email` varchar(64) NOT NULL,
  `Phone_Number` bigint(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`Tenant_ID`, `Home_ID`, `First_Name`, `Last_Name`, `Email`, `Phone_Number`) VALUES
(47, 35, 'Jon', 'Smith', 'jonsmith@gmail.com', 123456789),
(48, 35, 'Mary', 'Smith', 'marysmith@gmail.com', 123456789);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` mediumint(8) UNSIGNED NOT NULL,
  `First_Name` varchar(32) NOT NULL,
  `Last_Name` varchar(32) NOT NULL,
  `Password` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Email` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Phone_Number` varchar(16) NOT NULL,
  `Role` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `First_Name`, `Last_Name`, `Password`, `Email`, `Phone_Number`, `Role`) VALUES
(34, 'Admin', 'Admin', '$2y$10$Og/e6QDYzsHMHuNgIBqH3.68jyJZnSYa1sLbKwLPACfyLTS/s.ZpK', 'admin@tst.com', '000000', 3),
(40, 'Chandler', 'Farmer', '$2y$10$MI3cG5ZjSThiEVYhWL5JROaU2rAV7cU0mAxLVYdWjcJIVIRpgiC.u', 'landlord@gmail.com', '8596059282', 0),
(41, 'Tenant', 'Tester', '$2y$10$jH2oFDDMUhMuv5vtkAwcMe2O5R4kbar3GBYAWpVlSCxk7lNWtemXi', 'tenantester@gmail.com', '859-620-6607', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `docs/bills`
--
ALTER TABLE `docs/bills`
  ADD PRIMARY KEY (`Doc_ID`),
  ADD KEY `Tenant_ID` (`Tenant_ID`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`Home_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`Tenant_ID`),
  ADD KEY `Home_ID` (`Home_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `docs/bills`
--
ALTER TABLE `docs/bills`
  MODIFY `Doc_ID` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `Home_ID` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `Tenant_ID` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_ID` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `docs/bills`
--
ALTER TABLE `docs/bills`
  ADD CONSTRAINT `docs/bills_ibfk_1` FOREIGN KEY (`Tenant_ID`) REFERENCES `tenants` (`Tenant_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `home`
--
ALTER TABLE `home`
  ADD CONSTRAINT `home_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tenants`
--
ALTER TABLE `tenants`
  ADD CONSTRAINT `tenants_ibfk_1` FOREIGN KEY (`Home_ID`) REFERENCES `home` (`Home_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
